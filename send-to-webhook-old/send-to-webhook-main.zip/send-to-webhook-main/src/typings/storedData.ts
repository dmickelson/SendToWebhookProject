export interface StoredData {
  webhooks: string;
  previousIndex: number;
};
