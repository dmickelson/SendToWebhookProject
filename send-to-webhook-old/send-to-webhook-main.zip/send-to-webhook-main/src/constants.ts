export const HOWTO_CONFIG_URL = 'https://github.com/ericvan76/send-to-webhook/blob/master/README.md#how-to-configure';
export const DEVELOPERS_URL = 'https://github.com/ericvan76/send-to-webhook';
export const ISSUES_URL = 'https://github.com/ericvan76/send-to-webhook/issues';
export const DONATE_URL = 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=YQC5T9DVNEHPU';
